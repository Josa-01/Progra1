class Curso:
    def __init__(self, codigo, nombre):
        self.codigo = codigo
        self.nombre = nombre

    def mostrar_info(self):
        print(f"Código: {self.codigo}")
        print(f"Nombre del curso: {self.nombre}")

# Lista global de cursos para validar
cursos_disponibles = []

def agregar_curso(codigo, nombre):
    curso = Curso(codigo, nombre)
    cursos_disponibles.append(curso)

def validar_curso(codigo):
    for curso in cursos_disponibles:
        if curso.codigo == codigo:
            return True
    return False