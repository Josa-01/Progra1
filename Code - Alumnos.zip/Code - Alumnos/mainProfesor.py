from profesor import crear_profesor

def main():
    print("Registro de profesor")
    profesor = crear_profesor()
    print("\nDatos del profesor ingresados:")
    profesor.mostrar_info()

if __name__ == "__main__":
    main()