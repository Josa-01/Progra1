# estudiantes.py

class Estudiante:
    def __init__(self, cedula, nombre, nota):
        self.cedula = cedula
        self.nombre = nombre
        self.nota = nota

# Lista para almacenar estudiantes
estudiantes = []

def agregar_estudiante(cedula, nombre, nota):
    estudiante = Estudiante(cedula, nombre, nota)
    estudiantes.append(estudiante)

def obtener_reporte():
    total_estudiantes = len(estudiantes)
    if total_estudiantes == 0:
        print("No hay estudiantes registrados.")
        return
    
    suma_notas = sum(e.nota for e in estudiantes)
    promedio = suma_notas / total_estudiantes

    aprobados = len([e for e in estudiantes if e.nota > 70])
    aplazados = len([e for e in estudiantes if 60 <= e.nota <= 69])
    reprobados = len([e for e in estudiantes if e.nota < 60])
    superiores_promedio = len([e for e in estudiantes if e.nota > promedio])

    print(f"Total estudiantes: {total_estudiantes}")
    print(f"Promedio de notas: {promedio:.2f}")
    print(f"Estudiantes aprobados (>70): {aprobados}")
    print(f"Estudiantes aplazados (60-69): {aplazados}")
    print(f"Estudiantes reprobados (<60): {reprobados}")
    print(f"Estudiantes con nota superior al promedio: {superiores_promedio}")