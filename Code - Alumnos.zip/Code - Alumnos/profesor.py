from cursos import validar_curso

class Profesor:
    def __init__(self, cedula, nombre, curso_codigo):
        self.cedula = cedula
        self.nombre = nombre
        self.curso_codigo = curso_codigo

    def mostrar_info(self):
        print(f"Cédula: {self.cedula}")
        print(f"Nombre: {self.nombre}")
        print(f"Curso (Código): {self.curso_codigo}")

def crear_profesor():
    cedula = input("Ingrese la cédula del profesor: ")
    nombre = input("Ingrese el nombre del profesor: ")

    while True:
        curso = input("Ingrese el código del curso: ")
        if validar_curso(curso):
            break
        else:
            print("Curso no válido, por favor ingrese un curso existente.")

    profesor = Profesor(cedula, nombre, curso)
    return profesor