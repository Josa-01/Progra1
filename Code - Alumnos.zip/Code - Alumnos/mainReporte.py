from cursos import agregar_curso
from profesor import crear_profesor
from estudiantes import agregar_estudiante, obtener_reporte

def main():
    # Agregar cursos disponibles
    agregar_curso("MAT101", "Matemáticas")
    agregar_curso("FIS101", "Física")
    agregar_curso("HIS101", "Historia")

    # Crear profesor (con validación de curso)
    profesor = crear_profesor()
    print("\nProfesor registrado:")
    profesor.mostrar_info()

    # Ingresar estudiantes y sus notas
    while True:
        cedula = input("Ingrese cédula del estudiante (o 'salir' para terminar): ")
        if cedula.lower() == "salir":
            break
        nombre = input("Ingrese nombre del estudiante: ")
        while True:
            try:
                nota = float(input("Ingrese nota del estudiante (0-100): "))
                if 0 <= nota <= 100:
                    break
                else:
                    print("Nota inválida, debe estar entre 0 y 100.")
            except ValueError:
                print("Por favor, ingrese un número válido.")

        agregar_estudiante(cedula, nombre, nota)

    # Mostrar reporte
    print("\nReporte de estudiantes:")
    obtener_reporte()

if __name__ == "__main__":
    main()