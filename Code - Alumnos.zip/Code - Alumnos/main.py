import alumnos

def menu():
    while True:
        print("\n Sistema Escolar")
        print("1.Agregar\consultar Alumnos")
        print("2.Agregar\consultar Profesores")
        print("3.Agregar\consultar Cursos")
        print("4.Salir")
        
        opcion = input("Seleccione una opcion:")

        if opcion == '1':
            subopcion = input("a) Agregar Alumno\n b) Consultar Alumnos\n Seleccione una opcion").lower()
            if subopcion == 'a':
                nombre=input("Nombre alumno: ")
                cedula=input("Cedula alumno: ")
                curso=input("Curso alumno: ")
                nota=input("Nota alumno: ")
                alumnos.agregar_alumno(nombre, cedula, curso,nota)
            elif subopcion =='b':
                for a in alumnos.consultar_alumnos():
                    print(a)


if __name__ == "__main__":
            menu()